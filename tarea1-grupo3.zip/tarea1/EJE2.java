/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TAREAS.tarea1;

/**
 *
 * @author VIBEXZ
 */
public class EJE2 {
    
    /*
    
    // EL EJERCICO FUNCIONA, SOLO NO LOGRAMOS HACER EL BUCLE RECURSIVO PARA QUE DESPLIEGUE LETRA POR LETRA
    //PERO SI LE PASAS A palabra.charAT(n) esa n es el indice, el te imprime la letra de la palabra que corresponde a ese indice
    
    public static char eje2 (String palabra){
        
        int n = 0;
        
        if( n < palabra.length()){
            
            char c = palabra.charAt(n);
            n ++;
            
            return c;
        
        }
        return 0;
        
    }
    
    */
    
    
    
    
    
    
    
    
    
    
    
}
